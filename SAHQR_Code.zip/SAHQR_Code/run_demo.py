#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# SAHQR Online Demo — Command-line interface
#
# Copyright (c) 2026 Mohd Mufiz Arbee <arbee864@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
#
"""
SAHQR: Saliency-Aware Hybrid Quantum Image Representation — Demo Script

This script provides the command-line interface for the IPOL online demo.
It accepts a grayscale image, applies SAHQR encoding, and outputs:
  1. Saliency map overlay visualization
  2. Encoding metrics table (10 parameters)
  3. Comparison with baseline methods (optional)

Usage:
    python run_demo.py input.png --alpha 0.0 --output results/
    python run_demo.py input.png --compare  # Compare all 10 methods

See the paper:
    M. M. Arbee et al., "SAHQR: A Saliency-Aware Hybrid Quantum Image
    Representation for Efficient Medical Image Encoding",
    Image Processing On Line, 2026.
"""

import argparse
import json
import os
import sys
import time

import numpy as np
from PIL import Image

from sahqr import (
    encode_sahqr,
    encode_image_all_methods,
    generate_saliency_map,
    compute_evaluation_metrics,
    METHOD_NAMES,
    EVALUATION_PARAMS,
)


def load_and_preprocess(path, max_size=64):
    """
    Load an image, convert to grayscale, and resize if needed.

    Parameters
    ----------
    path : str
        Path to the input image (PNG or JPEG).
    max_size : int
        Maximum allowed dimension. Images larger than this are downscaled
        to ensure computation completes within the IPOL time limit.

    Returns
    -------
    image : numpy.ndarray
        Grayscale image of shape (H, W), dtype uint8.
    """
    img = Image.open(path).convert('L')
    w, h = img.size

    # Downscale if necessary (preserving aspect ratio, then crop to square)
    if max(w, h) > max_size:
        scale = max_size / max(w, h)
        new_w, new_h = int(w * scale), int(h * scale)
        img = img.resize((new_w, new_h), Image.LANCZOS)
        w, h = new_w, new_h

    # Crop to square
    side = min(w, h)
    left = (w - side) // 2
    top = (h - side) // 2
    img = img.crop((left, top, left + side, top + side))

    # Resize to nearest power of 2
    side = img.size[0]
    p2 = 2 ** int(np.ceil(np.log2(side)))
    if p2 > max_size:
        p2 = max_size
    img = img.resize((p2, p2), Image.LANCZOS)

    return np.array(img, dtype=np.uint8)


def save_saliency_overlay(image, saliency_map, output_path):
    """
    Save the saliency map overlaid on the original image.

    Salient regions are highlighted in green, non-salient in grayscale.
    """
    h, w = image.shape
    overlay = np.stack([image, image, image], axis=2)  # Grayscale to RGB

    # Highlight salient pixels in green
    green_mask = saliency_map == 1
    overlay[green_mask, 0] = np.clip(overlay[green_mask, 0] * 0.5, 0, 255)
    overlay[green_mask, 1] = np.clip(overlay[green_mask, 1] * 0.5 + 128, 0, 255)
    overlay[green_mask, 2] = np.clip(overlay[green_mask, 2] * 0.5, 0, 255)

    Image.fromarray(overlay.astype(np.uint8)).save(output_path)


def main():
    parser = argparse.ArgumentParser(
        description='SAHQR: Saliency-Aware Hybrid Quantum Image Representation',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  python run_demo.py test_data/sample_01.png
  python run_demo.py input.png --alpha 1.0 --output results/
  python run_demo.py input.png --compare --output results/
        ''')

    parser.add_argument('input', help='Path to input grayscale image (PNG/JPEG)')
    parser.add_argument('--alpha', type=float, default=0.0,
                        help='Saliency threshold sensitivity (default: 0.0)')
    parser.add_argument('--full-depth', type=int, default=8,
                        help='Full bit depth for salient pixels (default: 8)')
    parser.add_argument('--compressed-depth', type=int, default=4,
                        help='Compressed bit depth for background (default: 4)')
    parser.add_argument('--max-size', type=int, default=64,
                        help='Max image dimension in pixels (default: 64)')
    parser.add_argument('--output', type=str, default='output',
                        help='Output directory (default: output/)')
    parser.add_argument('--compare', action='store_true',
                        help='Compare SAHQR against all 10 baseline methods')

    args = parser.parse_args()

    # Validate input
    if not os.path.isfile(args.input):
        print(f"Error: Input file not found: {args.input}", file=sys.stderr)
        sys.exit(1)

    # Create output directory
    os.makedirs(args.output, exist_ok=True)

    # Load and preprocess image
    print(f"Loading image: {args.input}")
    image = load_and_preprocess(args.input, max_size=args.max_size)
    print(f"Image size: {image.shape[0]}x{image.shape[1]} pixels")
    print(f"Parameters: alpha={args.alpha}, q={args.full_depth}, q'={args.compressed_depth}")
    print()

    # Run SAHQR encoding
    print("Running SAHQR encoding...")
    t_start = time.time()
    result = encode_sahqr(image, alpha=args.alpha,
                          full_depth=args.full_depth,
                          compressed_depth=args.compressed_depth)
    total_time = (time.time() - t_start) * 1000

    # Compute metrics
    metrics = compute_evaluation_metrics(result, image_size=image.shape[0] * image.shape[1])

    # Print SAHQR results
    print(f"\n{'='*60}")
    print(f"SAHQR Encoding Results")
    print(f"{'='*60}")
    print(f"  Salient pixels:    {result['salient_pixels']} "
          f"({result['salient_ratio']*100:.1f}%)")
    print(f"  Background pixels: {result['background_pixels']} "
          f"({(1-result['salient_ratio'])*100:.1f}%)")
    print(f"  Total qubits:      {metrics['P1_Qubits_Required']}")
    print(f"  Circuit depth:     {metrics['P2_Circuit_Depth']}")
    print(f"  Gate count:        {metrics['P3_Gate_Count']}")
    print(f"  Encoding time:     {metrics['P4_Encoding_Time_ms']:.2f} ms")
    print(f"  Compression ratio: {metrics['P7_Compression_Ratio']:.4f}")
    print(f"  Gate complexity:   {metrics['P9_Gate_Complexity']:.4f}")
    print(f"  Total pipeline:    {total_time:.2f} ms")
    print(f"{'='*60}")

    # Save saliency overlay
    saliency_path = os.path.join(args.output, 'saliency_overlay.png')
    save_saliency_overlay(image, result['saliency_map'], saliency_path)
    print(f"\nSaliency overlay saved: {saliency_path}")

    # Save metrics as JSON
    metrics_out = {k: v for k, v in metrics.items() if k != 'method'}
    metrics_out['salient_ratio'] = result['salient_ratio']
    metrics_out['total_pipeline_time_ms'] = round(total_time, 2)
    metrics_path = os.path.join(args.output, 'metrics.json')
    with open(metrics_path, 'w') as f:
        json.dump(metrics_out, f, indent=2)
    print(f"Metrics saved: {metrics_path}")

    # Optional: compare with all baseline methods
    if args.compare:
        print(f"\n{'='*60}")
        print("Comparison with baseline methods")
        print(f"{'='*60}")
        all_results = encode_image_all_methods(image)
        print(f"\n{'Method':<12} {'Qubits':>8} {'Depth':>8} {'Gates':>10} "
              f"{'Time(ms)':>12} {'Compress':>10}")
        print("-" * 64)
        for name in METHOD_NAMES:
            r = all_results.get(name)
            if r is not None:
                m = compute_evaluation_metrics(r, image.shape[0] * image.shape[1])
                marker = ' <-- SAHQR' if name == 'SAHQR' else ''
                print(f"{name:<12} {m['P1_Qubits_Required']:>8} "
                      f"{m['P2_Circuit_Depth']:>8} "
                      f"{m['P3_Gate_Count']:>10} "
                      f"{m['P4_Encoding_Time_ms']:>12.2f} "
                      f"{m['P7_Compression_Ratio']:>10.4f}{marker}")
        print("-" * 64)

        # Save comparison as JSON
        comparison = {}
        for name in METHOD_NAMES:
            r = all_results.get(name)
            if r is not None:
                m = compute_evaluation_metrics(r, image.shape[0] * image.shape[1])
                comparison[name] = {k: v for k, v in m.items()}
        comp_path = os.path.join(args.output, 'comparison.json')
        with open(comp_path, 'w') as f:
            json.dump(comparison, f, indent=2)
        print(f"\nFull comparison saved: {comp_path}")


if __name__ == '__main__':
    main()
