SAHQR: Saliency-Aware Hybrid Quantum Image Representation
==========================================================

Version: 1.0
Date:    February 2026
Author:  Vrushali Sunil Nikam <vrushali.nik@gmail.com>

Paper:    V S Nikam et al., "SAHQR: An Efficient Saliency-Based Hybrid Quantum Scheme for Medical Image Representation ",Image Processing On Line, 2026.
         https://doi.org/10.5201/ipol

Overview
--------
This software implements the SAHQR algorithm for quantum image encoding.
SAHQR uses gradient-based saliency detection to allocate quantum resources
proportionally to image content importance: salient regions receive full-
precision encoding while non-salient backgrounds are compressed.

The code also includes 10 baseline quantum image encoding methods (FRQI,
NEQR, GQIR, MCQI, QRMW, EFRQI, 2D-QSNA, INEQR, QPIE, QLR) and a complete
10-parameter evaluation framework for comparison.

Files
-----
  sahqr.py          Main module: encoding methods, saliency, metrics
                    - generate_saliency_map()   -> Algorithm 2
                    - encode_sahqr()            -> Algorithm 1
                    - compute_evaluation_metrics() -> Algorithm 3
                    - encode_frqi(), encode_neqr(), etc. -> Section 2
  run_demo.py       CLI entry point for IPOL online demo
  requirements.txt  Python dependencies
  LICENSE.txt       GNU Affero General Public License v3
  test_data/        Sample 16x16 grayscale test images

Requirements
------------
  Python >= 3.8
  See requirements.txt for package dependencies.

  Install with: pip install -r requirements.txt

Usage
-----
  Basic SAHQR encoding:
    python run_demo.py test_data/brain_tumor_01.png

  With custom parameters:
    python run_demo.py input.png --alpha 1.0 --full-depth 8 --compressed-depth 4

  Compare all methods:
    python run_demo.py input.png --compare --output results/

  Full options:
    python run_demo.py --help

Output
------
  output/saliency_overlay.png  - Saliency map overlaid on input image
  output/metrics.json          - 10-parameter evaluation metrics
  output/comparison.json       - Full comparison (with --compare flag)

License
-------
Copyright (c) 2026 Mohd Mufiz Arbee.
Licensed under the GNU Affero General Public License v3.
See LICENSE.txt for details.
