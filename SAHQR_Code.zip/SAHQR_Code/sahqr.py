# -*- coding: utf-8 -*-
#
# SAHQR: Saliency-Aware Hybrid Quantum Image Representation
#
# Copyright (c) 2026 Mohd Mufiz Arbee <arbee864@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
#
"""
SAHQR: Saliency-Aware Hybrid Quantum Image Representation

This module implements the complete SAHQR encoding pipeline as described in:
    M. M. Arbee et al., "SAHQR: A Saliency-Aware Hybrid Quantum Image
    Representation for Efficient Medical Image Encoding",
    Image Processing On Line, 2026.

The module includes:
    - Saliency detection (Algorithm 2 in the paper)
    - SAHQR encoding (Algorithm 1 in the paper)
    - 10 baseline encoding methods for comparison
    - 10-parameter evaluation framework (Algorithm 3 in the paper)

Usage:
    from sahqr import encode_sahqr, generate_saliency_map, compute_evaluation_metrics
    result = encode_sahqr(image)
    metrics = compute_evaluation_metrics(result)
"""

import os
import time
import math
import warnings

import numpy as np
from scipy import ndimage

# Qiskit imports
from qiskit import QuantumCircuit

warnings.filterwarnings('ignore')


# ============================================================================
# SALIENCY DETECTION — Algorithm 2 in the paper
# ============================================================================

def generate_saliency_map(image, alpha=0.0):
    """
    Compute gradient-based saliency map with adaptive thresholding.

    Implements Algorithm 2 (Saliency Detection and Region Partitioning)
    from the paper:
        Step 1: Compute horizontal and vertical gradients using Sobel operators
        Step 2: Compute gradient magnitude and normalize to [0,1]
        Step 3: Apply adaptive threshold theta_s = mu_S + alpha * sigma_S
        Step 4: Classify pixels into salient (Omega_S) and non-salient (Omega_N)

    Parameters
    ----------
    image : numpy.ndarray
        Input grayscale image of shape (H, W), dtype uint8 or float.
    alpha : float, optional
        Sensitivity parameter for adaptive thresholding (default 0.0).
        Higher values classify fewer pixels as salient.
        Corresponds to parameter alpha in Equation (7) of the paper.

    Returns
    -------
    saliency_map : numpy.ndarray
        Binary saliency mask of shape (H, W), dtype uint8.
        1 = salient (Omega_S), 0 = non-salient (Omega_N).
    """
    img = image.astype(np.float64)

    # Step 1: Gradient computation using Sobel operators (Eq. 6 in paper)
    # Sobel kernels K_x and K_y as defined in Algorithm 2
    sobel_x = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=np.float64)
    sobel_y = np.array([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=np.float64)

    gx = ndimage.convolve(img, sobel_x)  # G_x(y,x) = I * K_x
    gy = ndimage.convolve(img, sobel_y)  # G_y(y,x) = I * K_y

    # Step 2: Gradient magnitude and normalization (Eq. 7 in paper)
    gradient_mag = np.sqrt(gx ** 2 + gy ** 2)
    max_val = gradient_mag.max()
    if max_val > 1e-10:
        S = gradient_mag / max_val  # Normalize to [0, 1]
    else:
        S = np.zeros_like(gradient_mag)

    # Step 3: Adaptive thresholding (Eq. 8 in paper)
    mu_S = np.mean(S)
    sigma_S = np.std(S)
    theta_s = mu_S + alpha * sigma_S

    # Step 4: Region classification
    saliency_map = (S >= theta_s).astype(np.uint8)

    return saliency_map


# ============================================================================
# SAHQR ENCODING — Algorithm 1 in the paper
# ============================================================================

def encode_sahqr(image, alpha=0.0, full_depth=8, compressed_depth=4):
    """
    SAHQR: Saliency-Aware Hybrid Quantum Image Representation.

    Implements Algorithm 1 from the paper:
        Phase 1: Saliency detection via Algorithm 2
        Phase 2: Region partitioning into Omega_S and Omega_N
        Phase 3: Quantum circuit construction with dual-layer encoding
            - Salient pixels: full-depth NEQR encoding with flag qubit = |1>
            - Non-salient pixels: compressed encoding with flag qubit = |0>

    Parameters
    ----------
    image : numpy.ndarray
        Input grayscale image of shape (H, W), dtype uint8.
        Must be square with dimensions that are a power of 2.
    alpha : float, optional
        Saliency sensitivity parameter (default 0.0). See Algorithm 2.
    full_depth : int, optional
        Bit depth for salient pixel encoding (default 8).
        Corresponds to q in the paper.
    compressed_depth : int, optional
        Bit depth for non-salient pixel encoding (default 4).
        Corresponds to q' in the paper.

    Returns
    -------
    result : dict
        Dictionary containing:
        - 'method': 'SAHQR'
        - 'circuit': qiskit.QuantumCircuit object
        - 'qubits': int, number of qubits used
        - 'gates': int, total gate count
        - 'depth': int, circuit depth
        - 'encoding_time': float, encoding time in milliseconds
        - 'salient_pixels': int, count of salient pixels
        - 'background_pixels': int, count of non-salient pixels
        - 'salient_ratio': float, fraction of salient pixels
        - 'saliency_map': numpy.ndarray, the binary saliency mask
    """
    start_time = time.time()

    height, width = image.shape
    n_pixels = height * width
    n_position_qubits = int(np.ceil(np.log2(n_pixels)))  # 2n in paper
    n_color_qubits = full_depth  # q in paper
    n_flag_qubit = 1  # Saliency flag qubit

    total_qubits = n_position_qubits + n_color_qubits + n_flag_qubit
    qc = QuantumCircuit(total_qubits)

    # Phase 1: Saliency detection (Algorithm 2)
    saliency_map = generate_saliency_map(image, alpha=alpha)

    # Phase 2: Region partitioning
    flat_image = image.flatten()
    flat_saliency = saliency_map.flatten()

    salient_count = int(np.sum(flat_saliency))
    background_count = n_pixels - salient_count

    # Compute background average for compressed encoding
    background_mask = flat_saliency == 0
    if np.any(background_mask):
        background_avg = int(np.mean(flat_image[background_mask]))
    else:
        background_avg = 128

    # Phase 3: Circuit construction
    # Apply Hadamard to position qubits (H^{2n})
    for i in range(n_position_qubits):
        qc.h(i)

    flag_qubit = total_qubits - 1  # Last qubit is saliency flag

    for idx in range(n_pixels):
        is_salient = flat_saliency[idx] == 1
        pixel_val = int(flat_image[idx])
        ctrl_state = format(idx, f'0{n_position_qubits}b')

        if is_salient:
            # Full-precision encoding for salient pixels (q bits)
            binary_rep = format(pixel_val, f'0{full_depth}b')
            for bit_pos, bit in enumerate(binary_rep):
                if bit == '1':
                    target = n_position_qubits + bit_pos
                    qc.mcx(list(range(n_position_qubits)), target,
                           ctrl_state=ctrl_state)
            # Set saliency flag to |1>
            qc.mcx(list(range(n_position_qubits)), flag_qubit,
                    ctrl_state=ctrl_state)
        else:
            # Compressed encoding for background pixels (q' bits)
            quantized = pixel_val >> (full_depth - compressed_depth)
            binary_rep = format(quantized, f'0{compressed_depth}b')
            # Pad to full depth for circuit compatibility
            binary_rep = binary_rep + '0' * (full_depth - compressed_depth)
            for bit_pos, bit in enumerate(binary_rep):
                if bit == '1':
                    target = n_position_qubits + bit_pos
                    qc.mcx(list(range(n_position_qubits)), target,
                           ctrl_state=ctrl_state)
            # Flag stays |0> for background

    encoding_time = (time.time() - start_time) * 1000
    salient_ratio = salient_count / n_pixels

    return {
        'method': 'SAHQR',
        'circuit': qc,
        'qubits': qc.num_qubits,
        'gates': qc.size(),
        'depth': qc.depth(),
        'encoding_time': encoding_time,
        'salient_pixels': salient_count,
        'background_pixels': background_count,
        'salient_ratio': salient_ratio,
        'saliency_map': saliency_map,
        'background_avg': background_avg
    }


# ============================================================================
# BASELINE ENCODING METHODS (Section 2 of the paper)
# ============================================================================

def encode_frqi(image):
    """
    FRQI: Flexible Representation of Quantum Images (Le et al., 2011).

    Encodes pixel intensities as rotation angles on a single color qubit.
    See Section 2.1 and Table 1 in the paper.

    Qubits: n (position) + 1 (color) = 9 for 16x16 image.
    """
    start_time = time.time()
    height, width = image.shape
    n_pixels = height * width
    n_position_qubits = int(np.ceil(np.log2(n_pixels)))

    qc = QuantumCircuit(n_position_qubits + 1)
    for i in range(n_position_qubits):
        qc.h(i)

    for idx, pixel in enumerate(image.flatten()):
        theta = float(pixel) * (np.pi / 2) / 255.0
        if theta > 1e-10:
            qc.ry(theta, n_position_qubits)

    encoding_time = (time.time() - start_time) * 1000
    return {
        'method': 'FRQI', 'circuit': qc, 'qubits': qc.num_qubits,
        'gates': qc.size(), 'depth': qc.depth(),
        'encoding_time': encoding_time
    }


def encode_neqr(image):
    """
    NEQR: Novel Enhanced Quantum Representation (Zhang et al., 2013).

    Encodes 8-bit pixel values as basis states using multi-controlled X gates.
    See Section 2.2 and Table 1 in the paper.

    Qubits: n (position) + 8 (color) = 16 for 16x16 image.
    """
    start_time = time.time()
    height, width = image.shape
    n_pixels = height * width
    n_position_qubits = int(np.ceil(np.log2(n_pixels)))
    n_color_qubits = 8

    qc = QuantumCircuit(n_position_qubits + n_color_qubits)
    for i in range(n_position_qubits):
        qc.h(i)

    for idx, pixel in enumerate(image.flatten()):
        binary_rep = format(int(pixel), '08b')
        ctrl_state = format(idx, f'0{n_position_qubits}b')
        for bit_pos, bit in enumerate(binary_rep):
            if bit == '1':
                target = n_position_qubits + bit_pos
                qc.mcx(list(range(n_position_qubits)), target,
                        ctrl_state=ctrl_state)

    encoding_time = (time.time() - start_time) * 1000
    return {
        'method': 'NEQR', 'circuit': qc, 'qubits': qc.num_qubits,
        'gates': qc.size(), 'depth': qc.depth(),
        'encoding_time': encoding_time
    }


def encode_gqir(image, color_bits=4):
    """
    GQIR: Generalized Quantum Image Representation (Jiang et al., 2015).

    NEQR variant with flexible bit depth for color encoding.
    See Section 2.3 and Table 1 in the paper.

    Qubits: n (position) + color_bits = 12 for 4-bit, 16x16 image.
    """
    start_time = time.time()
    height, width = image.shape
    n_pixels = height * width
    n_position_qubits = int(np.ceil(np.log2(n_pixels)))

    qc = QuantumCircuit(n_position_qubits + color_bits)
    for i in range(n_position_qubits):
        qc.h(i)

    max_val = (2 ** color_bits) - 1
    for idx, pixel in enumerate(image.flatten()):
        quantized = int((float(pixel) / 255.0) * max_val)
        binary_rep = format(quantized, f'0{color_bits}b')
        ctrl_state = format(idx, f'0{n_position_qubits}b')
        for bit_pos, bit in enumerate(binary_rep):
            if bit == '1':
                target = n_position_qubits + bit_pos
                qc.mcx(list(range(n_position_qubits)), target,
                        ctrl_state=ctrl_state)

    encoding_time = (time.time() - start_time) * 1000
    return {
        'method': 'GQIR', 'circuit': qc, 'qubits': qc.num_qubits,
        'gates': qc.size(), 'depth': qc.depth(),
        'encoding_time': encoding_time, 'color_bits': color_bits
    }


def encode_mcqi(image, num_channels=3):
    """
    MCQI: Multi-Channel Quantum Images (Sun et al., 2013).

    Multi-channel extension of NEQR for RGB-style encoding.
    See Section 2.4 and Table 1 in the paper.

    Qubits: n (position) + 8 (color) + ceil(log2(channels)) = 18 for 16x16.
    """
    start_time = time.time()
    height, width = image.shape
    n_pixels = height * width
    n_position_qubits = int(np.ceil(np.log2(n_pixels)))
    n_color_qubits = 8
    n_channel_qubits = int(np.ceil(np.log2(num_channels)))
    total_qubits = n_position_qubits + n_color_qubits + n_channel_qubits

    qc = QuantumCircuit(total_qubits)
    for i in range(n_position_qubits):
        qc.h(i)
    for i in range(n_channel_qubits):
        qc.h(n_position_qubits + n_color_qubits + i)

    for channel in range(num_channels):
        channel_state = format(channel, f'0{n_channel_qubits}b')
        for idx, pixel in enumerate(image.flatten()):
            binary_rep = format(int(pixel), '08b')
            pos_state = format(idx, f'0{n_position_qubits}b')
            ctrl_qubits = list(range(n_position_qubits)) + \
                list(range(n_position_qubits + n_color_qubits, total_qubits))
            ctrl_state = pos_state + channel_state
            for bit_pos, bit in enumerate(binary_rep):
                if bit == '1':
                    target = n_position_qubits + bit_pos
                    qc.mcx(ctrl_qubits, target, ctrl_state=ctrl_state)

    encoding_time = (time.time() - start_time) * 1000
    return {
        'method': 'MCQI', 'circuit': qc, 'qubits': qc.num_qubits,
        'gates': qc.size(), 'depth': qc.depth(),
        'encoding_time': encoding_time
    }


def encode_qrmw(image, num_bands=3):
    """
    QRMW: Quantum Representation for Multi-Wavelength Images (Wang et al., 2016).

    Multi-wavelength extension for hyperspectral imaging. Encodes K spectral
    bands with basis-state addressing for band selection.
    See Section 2.5 and Table 1 in the paper.

    Qubits: n (position) + 8 (color) + ceil(log2(K)) = 18 for 16x16 image.
    """
    start_time = time.time()
    height, width = image.shape
    n_pixels = height * width
    n_position_qubits = int(np.ceil(np.log2(n_pixels)))
    n_color_qubits = 8
    n_band_qubits = int(np.ceil(np.log2(num_bands)))
    total_qubits = n_position_qubits + n_color_qubits + n_band_qubits

    qc = QuantumCircuit(total_qubits)
    for i in range(n_position_qubits):
        qc.h(i)
    for i in range(n_band_qubits):
        qc.h(n_position_qubits + n_color_qubits + i)

    for band in range(num_bands):
        band_state = format(band, f'0{n_band_qubits}b')
        for idx, pixel in enumerate(image.flatten()):
            binary_rep = format(int(pixel), '08b')
            pos_state = format(idx, f'0{n_position_qubits}b')
            ctrl_qubits = list(range(n_position_qubits)) + \
                list(range(n_position_qubits + n_color_qubits, total_qubits))
            ctrl_state = pos_state + band_state
            for bit_pos, bit in enumerate(binary_rep):
                if bit == '1':
                    target = n_position_qubits + bit_pos
                    qc.mcx(ctrl_qubits, target, ctrl_state=ctrl_state)

    encoding_time = (time.time() - start_time) * 1000
    return {
        'method': 'QRMW', 'circuit': qc, 'qubits': qc.num_qubits,
        'gates': qc.size(), 'depth': qc.depth(),
        'encoding_time': encoding_time
    }


def encode_efrqi(image, angle_levels=32):
    """
    EFRQI: Enhanced Flexible Representation (Sang et al., 2017).

    FRQI variant with quantized rotation angles for reduced gate complexity.
    See Section 2.6 and Table 1 in the paper.

    Qubits: n (position) + 1 (color) = 9 for 16x16 image.
    """
    start_time = time.time()
    height, width = image.shape
    n_pixels = height * width
    n_position_qubits = int(np.ceil(np.log2(n_pixels)))

    qc = QuantumCircuit(n_position_qubits + 1)
    for i in range(n_position_qubits):
        qc.h(i)

    angle_groups = {}
    for idx, pixel in enumerate(image.flatten()):
        level = int((float(pixel) / 255.0) * (angle_levels - 1))
        theta = level * (np.pi / 2) / (angle_levels - 1)
        theta_key = round(theta, 6)
        if theta_key not in angle_groups:
            angle_groups[theta_key] = []
        angle_groups[theta_key].append(idx)

    for theta, indices in angle_groups.items():
        if theta > 1e-10:
            for _ in indices:
                qc.ry(theta, n_position_qubits)

    encoding_time = (time.time() - start_time) * 1000
    return {
        'method': 'EFRQI', 'circuit': qc, 'qubits': qc.num_qubits,
        'gates': qc.size(), 'depth': qc.depth(),
        'encoding_time': encoding_time
    }


def encode_2d_qsna(image):
    """
    2D-QSNA: 2D Quantum State Normalization Approach.

    Amplitude encoding with L2 normalization and recursive decomposition.
    See Section 2.7 and Table 1 in the paper.

    Qubits: n = log2(pixels) = 8 for 16x16 image (most compact).
    """
    start_time = time.time()
    height, width = image.shape
    n_pixels = height * width
    n_qubits = int(np.ceil(np.log2(n_pixels)))

    qc = QuantumCircuit(n_qubits)
    pixels = image.flatten().astype(np.float64)
    norm = np.sqrt(np.sum(pixels ** 2))
    if norm > 1e-10:
        amplitudes = pixels / norm
    else:
        amplitudes = np.ones(n_pixels) / np.sqrt(n_pixels)

    target_size = 2 ** n_qubits
    if len(amplitudes) < target_size:
        amplitudes = np.pad(amplitudes, (0, target_size - len(amplitudes)))
    norm = np.sqrt(np.sum(amplitudes ** 2))
    if norm > 1e-10:
        amplitudes = amplitudes / norm

    def _apply_amp_enc(qc, amps, qubits):
        if len(qubits) == 0:
            return
        half = len(amps) // 2
        left_n = np.sqrt(np.sum(amps[:half] ** 2))
        right_n = np.sqrt(np.sum(amps[half:] ** 2))
        total_n = np.sqrt(left_n ** 2 + right_n ** 2)
        if total_n > 1e-10:
            theta = 2 * np.arccos(np.clip(left_n / total_n, -1, 1))
            if not np.isnan(theta) and abs(theta) > 1e-10:
                qc.ry(theta, qubits[0])
        if len(qubits) > 1 and half > 1:
            la = amps[:half]
            s = np.sum(la ** 2)
            if s > 1e-10:
                la = la / np.sqrt(s)
            _apply_amp_enc(qc, la, qubits[1:])

    _apply_amp_enc(qc, amplitudes, list(range(n_qubits)))

    encoding_time = (time.time() - start_time) * 1000
    return {
        'method': '2D-QSNA', 'circuit': qc, 'qubits': qc.num_qubits,
        'gates': qc.size(), 'depth': qc.depth(),
        'encoding_time': encoding_time
    }


def encode_ineqr(image):
    """
    INEQR: Improved Novel Enhanced Quantum Representation (Jiang et al., 2015).

    XOR-based differential encoding between adjacent pixels.
    See Section 2.8 and Table 1 in the paper.

    Qubits: n (position) + 8 (color) = 16 for 16x16 image.
    """
    start_time = time.time()
    height, width = image.shape
    n_pixels = height * width
    n_position_qubits = int(np.ceil(np.log2(n_pixels)))
    n_color_qubits = 8

    qc = QuantumCircuit(n_position_qubits + n_color_qubits)
    for i in range(n_position_qubits):
        qc.h(i)

    prev_pixel = 0
    for idx, pixel in enumerate(image.flatten()):
        pixel_val = int(pixel)
        xor_val = pixel_val ^ prev_pixel
        binary_rep = format(xor_val, '08b')
        ctrl_state = format(idx, f'0{n_position_qubits}b')
        for bit_pos, bit in enumerate(binary_rep):
            if bit == '1':
                target = n_position_qubits + bit_pos
                qc.mcx(list(range(n_position_qubits)), target,
                        ctrl_state=ctrl_state)
        prev_pixel = pixel_val

    encoding_time = (time.time() - start_time) * 1000
    return {
        'method': 'INEQR', 'circuit': qc, 'qubits': qc.num_qubits,
        'gates': qc.size(), 'depth': qc.depth(),
        'encoding_time': encoding_time
    }


def encode_qpie(image):
    """
    QPIE: Quantum Probability Image Encoding.

    Pixels encoded as probability amplitudes via phase rotations.
    See Section 2.9 and Table 1 in the paper.

    Qubits: n = log2(pixels) = 8 for 16x16 image.
    """
    start_time = time.time()
    height, width = image.shape
    n_pixels = height * width
    n_qubits = int(np.ceil(np.log2(n_pixels)))

    qc = QuantumCircuit(n_qubits)
    pixels = image.flatten().astype(np.float64)
    norm = np.linalg.norm(pixels)
    if norm > 1e-10:
        amplitudes = pixels / norm
    else:
        amplitudes = np.ones(n_pixels) / np.sqrt(n_pixels)

    phases = np.arctan2(amplitudes, np.max(amplitudes)) * 2
    for i in range(n_qubits):
        qc.h(i)

    for idx, phase in enumerate(phases):
        if abs(phase) > 1e-10:
            ctrl_state = format(idx, f'0{n_qubits}b')
            qc.mcp(phase, list(range(n_qubits - 1)), n_qubits - 1,
                    ctrl_state=ctrl_state[:-1] if len(ctrl_state) > 1 else None)

    encoding_time = (time.time() - start_time) * 1000
    return {
        'method': 'QPIE', 'circuit': qc, 'qubits': qc.num_qubits,
        'gates': qc.size(), 'depth': qc.depth(),
        'encoding_time': encoding_time
    }


def encode_qlr(image):
    """
    QLR: Quantum Log-polar Representation.

    Log-polar coordinate transformation before NEQR encoding.
    See Section 2.10 and Table 1 in the paper.

    Qubits: n (position) + 8 (color) = 16 for 16x16 image.
    """
    start_time = time.time()
    height, width = image.shape
    n_pixels = height * width
    n_position_qubits = int(np.ceil(np.log2(n_pixels)))
    n_color_qubits = 8

    qc = QuantumCircuit(n_position_qubits + n_color_qubits)

    # Log-polar transformation
    center_x, center_y = width // 2, height // 2
    log_polar = np.zeros_like(image, dtype=np.uint8)
    max_r = np.sqrt(center_x ** 2 + center_y ** 2)
    for y in range(height):
        for x in range(width):
            dx, dy = x - center_x, y - center_y
            r = np.sqrt(dx ** 2 + dy ** 2)
            theta = np.arctan2(dy, dx)
            lr = np.log(r + 1) / np.log(max_r + 1) * (height - 1)
            lt = (theta + np.pi) / (2 * np.pi) * (width - 1)
            lr_i, lt_i = int(np.clip(lr, 0, height - 1)), int(np.clip(lt, 0, width - 1))
            log_polar[y, x] = image[lr_i, lt_i]

    for i in range(n_position_qubits):
        qc.h(i)

    for idx, pixel in enumerate(log_polar.flatten()):
        binary_rep = format(int(pixel), '08b')
        ctrl_state = format(idx, f'0{n_position_qubits}b')
        for bit_pos, bit in enumerate(binary_rep):
            if bit == '1':
                target = n_position_qubits + bit_pos
                qc.mcx(list(range(n_position_qubits)), target,
                        ctrl_state=ctrl_state)

    encoding_time = (time.time() - start_time) * 1000
    return {
        'method': 'QLR', 'circuit': qc, 'qubits': qc.num_qubits,
        'gates': qc.size(), 'depth': qc.depth(),
        'encoding_time': encoding_time
    }


# ============================================================================
# METHOD DISPATCHER
# ============================================================================

ENCODING_METHODS = {
    'FRQI': encode_frqi,
    'NEQR': encode_neqr,
    'GQIR': encode_gqir,
    'MCQI': encode_mcqi,
    'QRMW': encode_qrmw,
    'EFRQI': encode_efrqi,
    '2D-QSNA': encode_2d_qsna,
    'INEQR': encode_ineqr,
    'QPIE': encode_qpie,
    'QLR': encode_qlr,
    'SAHQR': encode_sahqr,
}

METHOD_NAMES = list(ENCODING_METHODS.keys())


def encode_image_all_methods(image, methods=None):
    """
    Encode an image using all or specified methods.

    Parameters
    ----------
    image : numpy.ndarray
        Grayscale image of shape (H, W).
    methods : list of str, optional
        Method names to use. Default: all 10 methods.

    Returns
    -------
    results : dict
        Dictionary mapping method name to encoding result dict.
    """
    if methods is None:
        methods = METHOD_NAMES
    results = {}
    for name in methods:
        if name in ENCODING_METHODS:
            try:
                results[name] = ENCODING_METHODS[name](image)
            except Exception as e:
                print(f"Warning: {name} failed: {e}")
                results[name] = None
    return results


# ============================================================================
# EVALUATION METRICS — Algorithm 3 in the paper
# ============================================================================

FRQI_BASELINE_QUBITS = 9

IMPLEMENTATION_COMPLEXITY = {
    'FRQI': 2, 'NEQR': 3, 'GQIR': 3, 'MCQI': 4, 'QRMW': 4,
    'EFRQI': 3, '2D-QSNA': 4, 'INEQR': 3,
    'QPIE': 4, 'QLR': 4, 'SAHQR': 5,
}

EVALUATION_PARAMS = [
    'P1_Qubits_Required', 'P2_Circuit_Depth', 'P3_Gate_Count',
    'P4_Encoding_Time_ms', 'P5_Scalability_Factor', 'P6_Information_Loss',
    'P7_Compression_Ratio', 'P8_Memory_Overhead', 'P9_Gate_Complexity',
    'P10_Implementation_Complexity',
]


def compute_evaluation_metrics(encoding_result, image_size=256):
    """
    Compute all 10 evaluation parameters for a single encoding result.

    Implements Algorithm 3 (SAHQR Evaluation Pipeline), specifically
    the inner loop that computes parameters p_1 through p_10.

    See Section 4.2 and Table 3 in the paper for parameter definitions.

    Parameters
    ----------
    encoding_result : dict
        Output from any encode_* function.
    image_size : int, optional
        Number of pixels (default 256 for 16x16).

    Returns
    -------
    metrics : dict
        Dictionary with keys P1_Qubits_Required through
        P10_Implementation_Complexity, plus method name.
    """
    if encoding_result is None:
        return None

    method = encoding_result['method']
    qubits = encoding_result['qubits']
    depth = encoding_result['depth']
    gates = encoding_result['gates']
    encoding_time = encoding_result['encoding_time']

    classical_bits = image_size * 8
    quantum_bits = qubits * depth if depth > 0 else qubits

    metrics = {
        'method': method,
        'P1_Qubits_Required': qubits,
        'P2_Circuit_Depth': depth,
        'P3_Gate_Count': gates,
        'P4_Encoding_Time_ms': round(encoding_time, 4),
        'P5_Scalability_Factor': round((1 / qubits) * 100, 4) if qubits > 0 else 0,
        'P6_Information_Loss': 0.0,
        'P7_Compression_Ratio': round(classical_bits / quantum_bits, 4) if quantum_bits > 0 else 0,
        'P8_Memory_Overhead': round((qubits / FRQI_BASELINE_QUBITS) * 100, 2),
        'P9_Gate_Complexity': round(gates / qubits, 4) if qubits > 0 else 0,
        'P10_Implementation_Complexity': IMPLEMENTATION_COMPLEXITY.get(method, 3),
    }

    if method == 'SAHQR':
        metrics['salient_ratio'] = encoding_result.get('salient_ratio', 0)
        metrics['salient_pixels'] = encoding_result.get('salient_pixels', 0)
        metrics['background_pixels'] = encoding_result.get('background_pixels', 0)

    return metrics
